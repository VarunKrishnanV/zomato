let body = document.querySelector("body")
let button = document.querySelector("button")

button.addEventListener('click', ()=>{
    body.style.backgroundColor = "orange";
})

console.log(button)

